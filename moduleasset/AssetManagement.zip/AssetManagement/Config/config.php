<?php

return [
    'name' => 'AssetManagement',
    'module_version' => "1.0",
    'pid' => 14
];
