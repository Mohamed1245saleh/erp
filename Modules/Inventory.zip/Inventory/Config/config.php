<?php

return [
    'name' => 'Inventory',
     'version' => "1.0"
];
